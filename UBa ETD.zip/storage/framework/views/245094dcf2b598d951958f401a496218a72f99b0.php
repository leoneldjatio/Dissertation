<div class="alert alert-warning">
    <strong>Warning!</strong>No search Results found for <b><?php echo e($query); ?></b>
</div>