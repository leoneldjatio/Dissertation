<?php $__env->startSection('content'); ?>
    <div id="gallery-page" class="container">
        <div class="row mt-5">
            <?php if(!Auth::guest()): ?>
                <div class="col-md-4 col-lg-3 col-sm-12 mb-3">
                    <a href="<?php echo e(action('UploadController@upload','')); ?>"><div class="card text-center add-project">
                            <div>
                                <img src="imgs/plus-icon.png" alt="plus icon">
                                <p>Add a project</p>
                            </div>
                        </div></a>
                </div>
            <?php endif; ?>
            <div class="col-md-9">
                <div class="row">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12 mb-3">
                    <div class="card">
                        <div class="card-header bg-dark text-white">
                            <h3 class="card-title"><?php echo e($datum->title); ?><br><span class="date-posted"><?php echo e($datum->created_at); ?></span></h3>
                        </div>
                        <div class="card-body">
                            <p class="abstract">
                                <?php echo e($datum->description); ?>

                                <a href="#" class="see-more">See more</a>
                            </p>

                        </div>
                        <div class="card-footer">
                            <div class="row">
                                <?php if(!Auth::guest()): ?>
                                    <a href="<?php echo e(url($datum->file_name)); ?>" class="card-link">Download</a>
                                <?php endif; ?>
                                <a href="<?php echo e(url($datum->file_name)); ?>" class="card-link">view</a>
                                <form method="POST" action="/delete/<?php echo e($datum->thesis_id); ?>" id="FormDeleteTime">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>


                                    <div class="form-group">
                                        <?php if(!Auth::guest()): ?>
                                            <input type="submit" class="btn btn-danger delete-thesis" data-toggle="confirmation" style="margin-left:30px; margin-bottom: -30px;margin-top: -20px" value="Delete">
                                        <?php endif; ?>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo e($data->links('vendor.pagination.bootstrap-4')); ?>

            </div>

        </div>
    </div>

    <div class="lightbox" style="display: none; position: fixed;  place-items: center; top: 0; left: 0; right:0; bottom: 0; background: rgba(0,0,0,0.5);">
        <div class="box" style="padding: 50px 80px; width: 80%; height: auto; position: relative;border: none; border-radius: 4px; background: white; z-index: 100;" >
            <h1 class="text-center">Project Abstract</h1><span class="close" style="position: absolute;  top: 20px; right: 20px; padding: 4px 8px; cursor: pointer; background: orangered; color: white; border-radius: 4px;">&times;</span><hr>
            <div class="content"></div>
        </div>
    </div>
    <script>
        const cardBody = document.querySelectorAll('.card-body');
        const abstracts = document.querySelectorAll('.abstract');
        const lightbox = document.querySelector('.lightbox');
        const bodyHeight = cardBody[0].offsetHeight;

        abstracts.forEach(function(abstract){
            if(abstract.offsetHeight > bodyHeight ) {
                // get its view more button
                const viewMore = abstract.querySelector('.see-more');
                viewMore.style.display = 'block';

                viewMore.addEventListener('click', function(){
                    lightbox.style.display = 'grid';
                    var content = document.querySelector('.lightbox .box .content');
                    content.innerHTML = abstract.innerHTML;
                    content.querySelector('.see-more').style.display = 'none';
                });
            }
        });

        const closebtn = document.querySelector('.lightbox .close');
        closebtn.addEventListener('click', function(){
            lightbox.style.display = 'none';
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>