<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    <title>UBaDissertations</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">


    <!-- Styles -->
    <!--<link href="<?php echo e(asset('sweetalert2.min.css')); ?>" rel="stylesheet">-->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap-reboot.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/select2.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet">

</head>
<body>
<div id="app">
    <?php $__env->startSection('navbar'); ?>
        <?php if(!Auth::guest()): ?>
            <?php echo $__env->make('layouts.navbar.navbar1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldSection(); ?>
    <?php else: ?>
        <?php echo $__env->make('layouts.navbar.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldSection(); ?>
    <?php endif; ?>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</div>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>" ></script>
<!--<script src="<?php echo e(asset('js/app.js')); ?>" ></script>-->
<script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('js/dropdown.js')); ?>" ></script>
<script src="<?php echo e(asset('js/styles.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-select.js')); ?>"></script>
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script type="text/javascript">
    $('#delete').on('show.bs.modal',function (event) {
        var button = $(event.relatedTarget)
        var thesis_id = button.data('id')
        var modal = $(this)
        modal.find('.modal-body #thesis').val(thesis_id)
    });
</script>
<script type="text/javascript">
    $('#deleteSearch').on('show.bs.modal',function (event) {
        var button = $(event.relatedTarget)
        var thesis_id = button.data('id')
        var modal = $(this)
        modal.find('.modal-body #SearchDel').val(thesis_id)
    });
</script>
</body>
</html>
