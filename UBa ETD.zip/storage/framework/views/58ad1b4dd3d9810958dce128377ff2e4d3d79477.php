<?php $__env->startSection('navbar'); ?>
    <header>
        <div class="container">
            <img src="<?php echo e(asset('imgs/UBAlogo.png')); ?>" style="max-width: 100%; width: 50px; height: 50px; margin-right: 10px;">
            <h1 class="logo"> UBa ETD</h1>
            <form action="/search" method="GET" role="search" style="padding-left: 10px;padding-top: 4px">
                <?php echo e(csrf_field()); ?>

                <div class="input-group">
                    <input type="text" class="form-control" name="query"
                           placeholder="Search projects"> <span class="input-group-btn">
            <button type="submit" class="btn btn-default">
                <i class="fa fa-search"></i>
            </button>
        </span>
                </div>
            </form>
            <nav class="navbar">
                <a href="/">home</a>
                <a href="<?php echo e(action('GalleryController@create','')); ?>">Browse Projects</a>
                <a href="#">faqs</a>
                <a href="<?php echo e(action('Auth\LoginController@login','')); ?>" class="btn btn-success">Sign In</a>
            </nav>
        </div>
    </header>
<?php $__env->stopSection(); ?>