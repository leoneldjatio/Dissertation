<?php $__env->startSection('content'); ?>
    <div id="gallery-page" class="container" style="margin-top: 20px">
        <div class="viewer" style="display: none;">
            <embed src="" type="application/pdf" style="width: 100%; height: 90vh;">
        </div>
        <div class="row mt-5">
            <?php if(!Auth::guest()): ?>
            <div class="col-md-4 col-lg-3 col-sm-12 mb-3">
                <a href="<?php echo e(action('UploadController@upload','')); ?>"><div class="card text-center add-project">
                    <div>
                        <img src="imgs/plus-icon.png" alt="plus icon">
                        <p>Add a project</p>
                    </div>
                    </div></a>
            </div>
            <?php endif; ?>
            <div class="col-md-9">
                <div class="row">
            <?php $__currentLoopData = $theses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thesis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12 mb-3">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        <h3 class="card-title"><?php echo e($thesis->title); ?><br><span class="date-posted"><?php echo e($thesis->created_at); ?></span></h3>
                    </div>
                    <div class="card-body">
                        <p class="abstract">
                            <?php echo e($thesis->description); ?>

                            <a href="#" class="see-more">See more</a>
                        </p>

                    </div>
                    <div class="card-footer">
                        <div class="row">
                            <?php if(!Auth::guest()): ?>
                        <a href="<?php echo e(url($thesis->file_name)); ?>" class="card-link">Download</a>
                            <?php endif; ?>
                                <a data-file="<?php echo e(url($thesis->file_name)); ?>" href="#" class="card-link ml-3">view</a>
                        <!--<button class="btn btn-primary" data-url="<?php echo e(url($thesis->file_name)); ?>" id="view">View</button>-->
                                <!--<iframe
                                        src="http://docs.google.com/gview?url=<?php echo e(asset($thesis->file_name)); ?>&embedded=true"
                                        style="width:600px; height:500px;"
                                        frameborder="0">
                                </iframe>-->
                            <form method="POST" action="/delete/<?php echo e($thesis->thesis_id); ?>" id="FormDeleteTime">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>


                                <div class="form-group">
                                    <?php if(!Auth::guest()): ?>
                                    <input type="submit" class="btn btn-danger delete-thesis" data-toggle="confirmation" style="margin-left:30px; margin-bottom: -30px;margin-top: -20px" value="Delete">
                                        <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo e($theses->links('vendor.pagination.bootstrap-4')); ?>

            </div>
        </div>
    </div>

    <div class="lightbox" style="display: none; position: fixed;  place-items: center; top: 0; left: 0; right:0; bottom: 0; background: rgba(0,0,0,0.5);">
        <div class="box" style="padding: 50px 80px; width: 100%; height: auto; position: relative;border: none; border-radius: 4px; background: white; z-index: 100;" >
            <h1 class="text-center heading">Project Abstract</h1><span class="close" style="position: absolute;  top: 20px; right: 20px; padding: 4px 8px; cursor: pointer; background: orangered; color: white; border-radius: 4px;">&times;</span><hr>
            <div class="content"></div>
        </div>
    </div>
    <script>
        const cardBody = document.querySelectorAll('.card-body');
        const abstracts = document.querySelectorAll('.abstract');
        const lightbox = document.querySelector('.lightbox');
        const bodyHeight = cardBody[0].offsetHeight;

        const viewBtns = document.querySelectorAll('.card-footer .card-link');
        viewBtns.forEach(function(view){
            view.addEventListener('click', function(){
                console.log(this.dataset.file);
                const viewer = document.querySelector('.viewer embed');
                viewer.setAttribute('src', this.dataset.file);
                document.querySelector('.lightbox .heading').style.display = 'none';
                document.querySelector('.lightbox .content').innerHTML = document.querySelector('.viewer').innerHTML;
                lightbox.style.display = 'block';
                const header = document.querySelector('header');
                header.style.position = 'static';
            });
        });

//
        abstracts.forEach(function(abstract){
           if(abstract.offsetHeight > bodyHeight ) {
               // get its view more button
               const viewMore = abstract.querySelector('.see-more');
               viewMore.style.display = 'block';

               // Change box width to 80% to suit abstract format
               const box = document.querySelector('.lightbox .box');

               viewMore.addEventListener('click', function(){
                    box.style.width = '80%';
                    lightbox.style.display = 'grid';
                    var content = document.querySelector('.lightbox .box .content');
                    content.innerHTML = abstract.innerHTML;
                    content.querySelector('.see-more').style.display = 'none';
               });

           }
        });

        const closebtn = document.querySelector('.lightbox .close');
        closebtn.addEventListener('click', function(){
            lightbox.style.display = 'none';
            document.querySelector('header').style.position = "sticky";
            document.querySelector('.lightbox .box').style.width = '100%';
            document.querySelector('.lightbox .heading').style.display = 'block';
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>